# 数据库模板
# TG:cupfoxone
# 博客地址 www.453u.cn

import datetime

from flask_login import UserMixin
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


class MacVod(db.Model):
    __tablename__ = 'mac_vod'

    vod_id = db.Column(db.Integer, primary_key=True)
    type_id = db.Column(db.SmallInteger, nullable=False, index=True, server_default=db.FetchedValue())
    type_id_1 = db.Column(db.SmallInteger, nullable=False, index=True, server_default=db.FetchedValue())
    group_id = db.Column(db.SmallInteger, nullable=False, index=True, server_default=db.FetchedValue())
    vod_name = db.Column(db.String(255), nullable=False, index=True, server_default=db.FetchedValue())
    vod_sub = db.Column(db.String(255), nullable=False, server_default=db.FetchedValue())
    vod_en = db.Column(db.String(255), nullable=False, index=True, server_default=db.FetchedValue())
    vod_status = db.Column(db.Integer, nullable=False, server_default=db.FetchedValue())
    vod_letter = db.Column(db.String(1), nullable=False, index=True, server_default=db.FetchedValue())
    vod_color = db.Column(db.String(6), nullable=False, server_default=db.FetchedValue())
    vod_tag = db.Column(db.String(100), nullable=False, index=True, server_default=db.FetchedValue())
    vod_class = db.Column(db.String(255), nullable=False, index=True, server_default=db.FetchedValue())
    vod_pic = db.Column(db.String(1024), nullable=False, server_default=db.FetchedValue())
    vod_pic_thumb = db.Column(db.String(1024), nullable=False, server_default=db.FetchedValue())
    vod_pic_slide = db.Column(db.String(1024), nullable=False, server_default=db.FetchedValue())
    vod_pic_screenshot = db.Column(db.Text)
    vod_actor = db.Column(db.String(255), nullable=False, index=True, server_default=db.FetchedValue())
    vod_director = db.Column(db.String(255), nullable=False, index=True, server_default=db.FetchedValue())
    vod_writer = db.Column(db.String(100), nullable=False, server_default=db.FetchedValue())
    vod_behind = db.Column(db.String(100), nullable=False, server_default=db.FetchedValue())
    vod_blurb = db.Column(db.String(255), nullable=False, server_default=db.FetchedValue())
    vod_remarks = db.Column(db.String(100), nullable=False, server_default=db.FetchedValue())
    vod_pubdate = db.Column(db.String(100), nullable=False, server_default=db.FetchedValue())
    vod_total = db.Column(db.Integer, nullable=False, index=True, server_default=db.FetchedValue())
    vod_serial = db.Column(db.String(20), nullable=False, server_default=db.FetchedValue())
    vod_tv = db.Column(db.String(30), nullable=False, server_default=db.FetchedValue())
    vod_weekday = db.Column(db.String(30), nullable=False, server_default=db.FetchedValue())
    vod_area = db.Column(db.String(20), nullable=False, index=True, server_default=db.FetchedValue())
    vod_lang = db.Column(db.String(10), nullable=False, index=True, server_default=db.FetchedValue())
    vod_year = db.Column(db.String(10), nullable=False, index=True, server_default=db.FetchedValue())
    vod_version = db.Column(db.String(30), nullable=False, index=True, server_default=db.FetchedValue())
    vod_state = db.Column(db.String(30), nullable=False, index=True, server_default=db.FetchedValue())
    vod_author = db.Column(db.String(60), nullable=False, server_default=db.FetchedValue())
    vod_jumpurl = db.Column(db.String(150), nullable=False, server_default=db.FetchedValue())
    vod_tpl = db.Column(db.String(30), nullable=False, server_default=db.FetchedValue())
    vod_tpl_play = db.Column(db.String(30), nullable=False, server_default=db.FetchedValue())
    vod_tpl_down = db.Column(db.String(30), nullable=False, server_default=db.FetchedValue())
    vod_isend = db.Column(db.Integer, nullable=False, index=True, server_default=db.FetchedValue())
    vod_lock = db.Column(db.Integer, nullable=False, index=True, server_default=db.FetchedValue())
    vod_level = db.Column(db.Integer, nullable=False, index=True, server_default=db.FetchedValue())
    vod_copyright = db.Column(db.Integer, nullable=False, server_default=db.FetchedValue())
    vod_points = db.Column(db.SmallInteger, nullable=False, server_default=db.FetchedValue())
    vod_points_play = db.Column(db.SmallInteger, nullable=False, index=True, server_default=db.FetchedValue())
    vod_points_down = db.Column(db.SmallInteger, nullable=False, index=True, server_default=db.FetchedValue())
    vod_hits = db.Column(db.Integer, nullable=False, index=True, server_default=db.FetchedValue())
    vod_hits_day = db.Column(db.Integer, nullable=False, index=True, server_default=db.FetchedValue())
    vod_hits_week = db.Column(db.Integer, nullable=False, index=True, server_default=db.FetchedValue())
    vod_hits_month = db.Column(db.Integer, nullable=False, index=True, server_default=db.FetchedValue())
    vod_duration = db.Column(db.String(10), nullable=False, server_default=db.FetchedValue())
    vod_up = db.Column(db.Integer, nullable=False, index=True, server_default=db.FetchedValue())
    vod_down = db.Column(db.Integer, nullable=False, index=True, server_default=db.FetchedValue())
    vod_score = db.Column(db.Numeric(3, 1), nullable=False, index=True, server_default=db.FetchedValue())
    vod_score_all = db.Column(db.Integer, nullable=False, index=True, server_default=db.FetchedValue())
    vod_score_num = db.Column(db.Integer, nullable=False, index=True, server_default=db.FetchedValue())
    vod_time = db.Column(db.Integer, nullable=False, index=True, server_default=db.FetchedValue())
    vod_time_add = db.Column(db.Integer, nullable=False, index=True, server_default=db.FetchedValue())
    vod_time_hits = db.Column(db.Integer, nullable=False, server_default=db.FetchedValue())
    vod_time_make = db.Column(db.Integer, nullable=False, index=True, server_default=db.FetchedValue())
    vod_trysee = db.Column(db.SmallInteger, nullable=False, server_default=db.FetchedValue())
    vod_douban_id = db.Column(db.Integer, nullable=False, server_default=db.FetchedValue())
    vod_douban_score = db.Column(db.Numeric(3, 1), nullable=False, server_default=db.FetchedValue())
    vod_reurl = db.Column(db.String(255), nullable=False, server_default=db.FetchedValue())
    vod_rel_vod = db.Column(db.String(255), nullable=False, server_default=db.FetchedValue())
    vod_rel_art = db.Column(db.String(255), nullable=False, server_default=db.FetchedValue())
    vod_pwd = db.Column(db.String(10), nullable=False, server_default=db.FetchedValue())
    vod_pwd_url = db.Column(db.String(255), nullable=False, server_default=db.FetchedValue())
    vod_pwd_play = db.Column(db.String(10), nullable=False, server_default=db.FetchedValue())
    vod_pwd_play_url = db.Column(db.String(255), nullable=False, server_default=db.FetchedValue())
    vod_pwd_down = db.Column(db.String(10), nullable=False, server_default=db.FetchedValue())
    vod_pwd_down_url = db.Column(db.String(255), nullable=False, server_default=db.FetchedValue())
    vod_content = db.Column(db.String, nullable=False)
    vod_play_from = db.Column(db.String(255), nullable=False, server_default=db.FetchedValue())
    vod_play_server = db.Column(db.String(255), nullable=False, server_default=db.FetchedValue())
    vod_play_note = db.Column(db.String(255), nullable=False, server_default=db.FetchedValue())
    vod_play_url = db.Column(db.String, nullable=False)
    vod_down_from = db.Column(db.String(255), nullable=False, server_default=db.FetchedValue())
    vod_down_server = db.Column(db.String(255), nullable=False, server_default=db.FetchedValue())
    vod_down_note = db.Column(db.String(255), nullable=False, server_default=db.FetchedValue())
    vod_down_url = db.Column(db.String, nullable=False)
    vod_plot = db.Column(db.Integer, nullable=False, index=True, server_default=db.FetchedValue())
    vod_plot_name = db.Column(db.String, nullable=False)
    vod_plot_detail = db.Column(db.String, nullable=False)


class Url_link(db.Model):
    __tablename__ = 'url_link'

    url_id = db.Column(db.Integer, primary_key=True)
    url_link_a = db.Column(db.String(255))
    url_link_b = db.Column(db.String(255))
    url_link_c = db.Column(db.String(255))
    url_link_d = db.Column(db.String(255))


class Adminmanage(db.Model, UserMixin):
    __tablename__ = 'admin'

    id = db.Column(db.Integer, primary_key=True)
    admin_name = db.Column(db.String(255))
    admin_pass = db.Column(db.String(255))
    page = db.Column(db.String(255))
    webname = db.Column(db.String(255))
    icpback = db.Column(db.String(255))
    appdown = db.Column(db.String(255))
    creation_date = db.Column(db.DateTime, default=datetime.datetime.now)


class MacCollect(db.Model):
    __tablename__ = 'mac_collect'

    collect_id = db.Column(db.Integer, primary_key=True)
    collect_name = db.Column(db.String(30), nullable=False, server_default=db.FetchedValue())
    collect_url = db.Column(db.String(255), nullable=False, server_default=db.FetchedValue())
    collect_type = db.Column(db.Integer, nullable=False, server_default=db.FetchedValue())
    collect_mid = db.Column(db.Integer, nullable=False, server_default=db.FetchedValue())
    collect_appid = db.Column(db.String(30), nullable=False, server_default=db.FetchedValue())
    collect_appkey = db.Column(db.String(30), nullable=False, server_default=db.FetchedValue())
    collect_param = db.Column(db.String(100), nullable=False, server_default=db.FetchedValue())
    collect_filter = db.Column(db.Integer, nullable=False, server_default=db.FetchedValue())
    collect_filter_from = db.Column(db.String(255), nullable=False, server_default=db.FetchedValue())
    collect_opt = db.Column(db.Integer, nullable=False, server_default=db.FetchedValue())
    collect_sync_pic_opt = db.Column(db.Integer, nullable=False, server_default=db.FetchedValue(),
                                     info='同步图片选项，0-跟随全局，1-开启，2-关闭')


class Ipadd(db.Model):
    __tablename__ = 'ipadd'
    id = db.Column(db.Integer, primary_key=True)
    ipaddr = db.Column(db.String(255))
    creation_date = db.Column(db.DateTime, default=datetime.datetime.now)


class Pvadd(db.Model):
    __tablename__ = 'pvadd'
    id = db.Column(db.Integer, primary_key=True)
    pvaddr = db.Column(db.Integer)
    creation_date = db.Column(db.DateTime, default=datetime.datetime.now)

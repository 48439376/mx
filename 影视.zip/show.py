import json
import random
import re

import requests
from flask import render_template, Blueprint, request, redirect, url_for, jsonify, send_file

from models import MacVod, db, Url_link, Pvadd, Adminmanage

show = Blueprint('show', __name__)


@show.route('/', methods=['POST', 'GET'])  # 首页判断是否登录
def blue_index():


    pv_in = db.session.query(Pvadd).first()
    pv_in.pvaddr = int(pv_in.pvaddr) + 1
    db.session.commit()
    webname = Adminmanage.query.filter(Adminmanage.id).first()

    # 电影分类 按点击量排序
    vod_list1 = MacVod.query.filter(
        db.or_(MacVod.type_id_1 == 1)).order_by(MacVod.vod_year.desc(), MacVod.vod_douban_score.desc(),
                                                MacVod.vod_time_add.desc()).limit(12)
    # 连续剧分类 按点击量排序
    vod_list2 = MacVod.query.filter(
        db.or_(MacVod.type_id_1 == 2)).order_by(MacVod.vod_year.desc(), MacVod.vod_douban_score.desc(),
                                                MacVod.vod_time_add.desc()).limit(12)
    # 动漫分类 按点击量排序
    vod_list3 = MacVod.query.filter(
        db.or_(MacVod.type_id_1 == 3)).order_by(MacVod.vod_year.desc(), MacVod.vod_douban_score.desc(),
                                                MacVod.vod_time_add.desc()).limit(12)
    # 综艺分类 按点击量排序
    vod_list4 = MacVod.query.filter(
        db.or_(MacVod.type_id_1 == 4)).order_by(MacVod.vod_year.desc(), MacVod.vod_douban_score.desc(),
                                                MacVod.vod_time_add.desc()).limit(12)

    vod_huandeng = MacVod.query.filter(MacVod.vod_pic_slide.ilike('%' + "http" + '%')).order_by(
        MacVod.vod_douban_score.desc(), MacVod.vod_year.desc(), MacVod.vod_time_add.desc()).limit(6)
    print(vod_huandeng)

    print(vod_list1)
    return render_template('kf.html', data1=vod_list1, data2=vod_list2, data3=vod_list3, data4=vod_list4,
                           vod_huandeng=vod_huandeng, webname=webname.webname, icpback=webname.icpback,
                           appdown=webname.appdown)



@show.route('/video/<path:name>', methods=['POST', 'GET'])  # 首页判断是否登录
def blue_list(name):
    urlload = name.strip('.html/')
    webname = Adminmanage.query.filter(Adminmanage.id).first()
    vod_list = MacVod.query.filter(MacVod.vod_id == urlload).first()
    print(urlload)
    from diskcache import Cache
    if vod_list:
        vod_list_list = MacVod.query.filter(MacVod.vod_class.ilike('%' + vod_list.vod_class[0] + '%')).order_by(
            MacVod.vod_hits.desc()).limit(6)
        url_link = Url_link.query.filter(Url_link.url_id).all()
        new_url_list = []

        for a in url_link:
            if a.url_link_b != '无':
                cache = Cache(f'./cache/{a.url_link_c}')
                getcache = cache.get(vod_list.vod_name, default=None)
                if getcache:
                    print(getcache)
                    new_url_list = getcache
                else:
                    try:
                        response = requests.get(a.url_link_a + "index.php/ajax/suggest?mid=1&wd=" + vod_list.vod_name)
                        if response.status_code == 200:
                            print(response.status_code)
                            json_list = json.dumps(response.text, ensure_ascii=False)
                            json_dict = json.loads(json_list)  # 转换成字典格式
                            json_dict = json.loads(json_dict)
                            video_list = json_dict['list']
                            print(video_list)
                            for i in video_list:
                                if i['name'] == vod_list.vod_name:
                                    print(i['name'], i['id'])
                                    data_dict = {"title": a.url_link_c, "url": a.url_link_b + str(i['id']) + '.html',
                                                 "tui": a.url_link_d, "video_name": vod_list.vod_name}
                                    new_url_list.append(data_dict)
                            cache.set(vod_list.vod_name, new_url_list)
                        else:
                            print(response.status_code)
                    except Exception as e:
                        print('无法访问该条目，跳过！')

            if a.url_link_b == '无':
                new_list_dict = {"title": a.url_link_c, "url": a.url_link_a + vod_list.vod_name,
                                 "tui": a.url_link_d, "video_name": vod_list.vod_name}
                print(new_url_list)
                new_url_list.append(new_list_dict)

        return render_template('kf_list.html', data=vod_list, data2=vod_list_list, url_link=new_url_list,
                               webname=webname.webname, icpback=webname.icpback,
                               appdown=webname.appdown)

    return render_template('kf_list.html', data="未查询到符合条件的电影", webname=webname.webname, icpback=webname.icpback,
                           appdown=webname.appdown)


import shutil


@show.route('/del/', methods=['POST', 'GET'])
def delcache():
    url_title = request.args.get('title')
    try:
        if url_title == 'all':
            shutil.rmtree(f'./cache')
        else:
            shutil.rmtree(f'./cache/{url_title}')
    except Exception as e:
        print(e)

    return redirect('/delcache/')


@show.route('/tiaozhuan/', methods=['POST', 'GET'])  # 是否添加iframe跳转头
def blue_tiaozhuan():
    urlload = request.args.get("url", "")
    titleload = request.args.get("title", "")

    return render_template('kf_tiaozhuan.html', data=urlload, data2=titleload)


@show.route('/down/', methods=['POST', 'GET'])  # 首页判断是否登录
def blue_down():
    webname = Adminmanage.query.filter(Adminmanage.id).first()
    return render_template('down.html', webname=webname.webname)


@show.route('/down1/', methods=['POST', 'GET'])  # 首页判断是否登录
def blue_down1():
    return send_file('anzhuo.apk')


@show.route('/down2/', methods=['POST', 'GET'])  # 首页判断是否登录
def blue_down2():
    return send_file('ios.mobileconfig')
# TG:cupfoxone
# 博客地址 www.453u.cn
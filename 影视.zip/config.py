# TG:cupfoxone
# 数据库配置
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

"""配置文件"""
import os.path

class Config(object):
    """项目配置文件"""
    # 数据库连接URI
    SQLALCHEMY_DATABASE_URI = "mysql+pymysql://数据库名:数据库密码@127.0.0.1:3306/数据库名"
    SQLALCHEMY_TRACK_MODIFICATIONS =True
    # flash,form wft
    SECRET_KEY = os.urandom(24)
    # 文件上传的根路径
    MEDIA_ROOT = os.path.join(os.path.dirname(__file__), 'medias')
    BABEL_DEFAULT_LOCALE = 'zh_CN'
    FLASK_ADMIN_SWATCH = 'cerulean'
    SQLALCHEMY_ECHO = True
    JSON_AS_ASCII = False
    JSONIFY_MIMETYPE = "application/json;charset=utf-8"

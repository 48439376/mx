# coding: utf-8
# TG:cupfoxone
# 地址 www.mbbsm.com
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


class Video(db.Model):
    __tablename__ = 'video'

    id = db.Column(db.Integer, primary_key=True)
    film_name = db.Column(db.Text)
    introduction = db.Column(db.Text)
    entry_time = db.Column(db.Text)
    release_time = db.Column(db.Text)
    gradegraded = db.Column(db.Text)
    language = db.Column(db.Text)
    class_fiction = db.Column(db.Text)
    class_type = db.Column(db.Text)
    area = db.Column(db.Text)
    performer = db.Column(db.Text)
    video_pic = db.Column(db.Text)

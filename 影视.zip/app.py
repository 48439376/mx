# -*- coding: utf-8 -*-
# TG:cupfoxone
# 博客地址 www.453u.cn

import os
from flask import Flask, request, redirect, url_for, render_template
from flask_babelex import Babel
from flask_cors import CORS
import config
from models import db
from show import show

app = Flask(__name__)
babel = Babel(app)
app.debug = True
CORS(app, resources=r'/*')
app.config.from_object(config.Config)
app.register_blueprint(show)

db.init_app(app)
